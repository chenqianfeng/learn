package coding.annotation;

public interface IAspect {
    void before();
    void after();
}
