package coding.sorting;

public interface IMutableSorter {
    void sort(int[] A);
}
