package coding.sorting;

import java.util.List;

public interface IImutableSorter {
    List<Integer> sort(List<Integer> A);
}
