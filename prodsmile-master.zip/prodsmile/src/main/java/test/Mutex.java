package test;

public class Mutex {

    public void lock() {
    }

    public void unlock(){
    }

    public static void main(String[] argv) {
        var mutex = new Mutex();
    }
}
